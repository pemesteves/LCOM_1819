var searchData=
[
  ['width',['width',['../struct_sprite.html#a0a3364944c5e361fc9e7ae406224d682',1,'Sprite']]]
];

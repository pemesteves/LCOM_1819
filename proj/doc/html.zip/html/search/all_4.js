var searchData=
[
  ['delay_5fus',['DELAY_US',['../group__i8042.html#ga1a522aa19bcb695a9df30032a893bee3',1,'8042.h']]],
  ['destroy_5fanimsprite',['destroy_animSprite',['../group___anim_sprite.html#ga0fb3b54f9fd63c899aafc7d9405ddf00',1,'destroy_animSprite(AnimSprite *sp):&#160;animSprite.c'],['../group___anim_sprite.html#ga0fb3b54f9fd63c899aafc7d9405ddf00',1,'destroy_animSprite(AnimSprite *sp):&#160;animSprite.c']]],
  ['destroy_5fenemies',['destroy_enemies',['../group___sprite.html#gae233c0a963c48029041587d8f5604d98',1,'destroy_enemies(uint8_t num_enemies, Sprite *enemies[]):&#160;sprite.c'],['../group___sprite.html#gae233c0a963c48029041587d8f5604d98',1,'destroy_enemies(uint8_t num_enemies, Sprite *enemies[]):&#160;sprite.c']]],
  ['destroy_5fsprite',['destroy_sprite',['../group___sprite.html#gaf16c6befaac9ffb673b9e3c798d542ed',1,'destroy_sprite(Sprite *sp):&#160;sprite.c'],['../group___sprite.html#gaf16c6befaac9ffb673b9e3c798d542ed',1,'destroy_sprite(Sprite *sp):&#160;sprite.c']]],
  ['direct_5fcolor_5fmode_5f888',['DIRECT_COLOR_MODE_888',['../group___proj.html#ga54d11988a09f006f2040f12594680da4',1,'proj.h']]],
  ['dis_5fkbd_5fint',['DIS_KBD_INT',['../group__i8042.html#gab1eb17cf8099fd1133c14cd6eb0ffa72',1,'8042.h']]],
  ['disable_5fdata_5freport',['DISABLE_DATA_REPORT',['../group__i8042.html#gad374b510092499b5961d3771abf9c66e',1,'8042.h']]],
  ['disable_5firq_5fline',['DISABLE_IRQ_LINE',['../group__i8042.html#gaf663bb79da759b50466f1625d464ffa9',1,'8042.h']]],
  ['disable_5fkbd_5finterface',['DISABLE_KBD_INTERFACE',['../group__i8042.html#gaf4de6eb113cbb16e0c04e4eed2e25f9d',1,'8042.h']]],
  ['disable_5fmouse',['DISABLE_MOUSE',['../group__i8042.html#ga12d3b0abea66d191d47fe6860e58865e',1,'8042.h']]],
  ['dm',['DM',['../group___r_t_c.html#ga9a9aac904e687286501946469e2903d6',1,'rtc.h']]],
  ['draw_5fenemies',['draw_enemies',['../group___sprite.html#gaa2c0f9732b683e00d6448947292e65b8',1,'draw_enemies(uint8_t num_enemies, Sprite *enemies[]):&#160;sprite.c'],['../group___sprite.html#gaa2c0f9732b683e00d6448947292e65b8',1,'draw_enemies(uint8_t num_enemies, Sprite *enemies[]):&#160;sprite.c']]],
  ['draw_5fhigh_5fscores',['draw_high_scores',['../group___highscores.html#ga2972cc645da17cb2293f7555b177a538',1,'draw_high_scores(bool firstTime):&#160;high_scores.c'],['../group___highscores.html#ga2972cc645da17cb2293f7555b177a538',1,'draw_high_scores(bool firstTime):&#160;high_scores.c']]],
  ['draw_5fscore',['draw_score',['../group___game.html#ga6f07ec8485043a4e9e3ec0a61037f50c',1,'draw_score(uint32_t score):&#160;game.c'],['../group___game.html#ga6f07ec8485043a4e9e3ec0a61037f50c',1,'draw_score(uint32_t score):&#160;game.c']]],
  ['draw_5fsprite',['draw_sprite',['../group___sprite.html#ga6c75fbf31230126d2f19b29deaf24b2f',1,'draw_sprite(Sprite *sp):&#160;sprite.c'],['../group___sprite.html#ga6c75fbf31230126d2f19b29deaf24b2f',1,'draw_sprite(Sprite *sp):&#160;sprite.c']]],
  ['drawbackground',['drawBackground',['../group___game.html#ga93473fd38afeaabd0805505b4331e55e',1,'drawBackground(bool isDay, bool first_time_drawing_background):&#160;game.c'],['../group___game.html#ga93473fd38afeaabd0805505b4331e55e',1,'drawBackground(bool isDay, bool first_time_drawing_background):&#160;game.c']]],
  ['drawpixel',['drawPixel',['../group___video_card.html#ga6091a4bd04596e6e8e39b7dee1e1b118',1,'drawPixel(uint16_t x, uint16_t y, uint32_t color):&#160;videoCard.c'],['../group___video_card.html#ga6091a4bd04596e6e8e39b7dee1e1b118',1,'drawPixel(uint16_t x, uint16_t y, uint32_t color):&#160;videoCard.c']]]
];

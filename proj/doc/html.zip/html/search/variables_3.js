var searchData=
[
  ['greenscreenmask',['greenScreenMask',['../video_card_8c.html#a33a147be7923782fb8219e1641711fce',1,'videoCard.c']]]
];

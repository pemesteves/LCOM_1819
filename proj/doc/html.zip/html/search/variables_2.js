var searchData=
[
  ['code',['code',['../group___keyboard.html#ga966576744a473fafb7687f8e5649941f',1,'code():&#160;keyboard.c'],['../group___keyboard.html#ga966576744a473fafb7687f8e5649941f',1,'code():&#160;keyboard.c']]],
  ['counter',['counter',['../group__i8254.html#ga51322ddb267b4729d6b5f2bb05d49fff',1,'counter():&#160;timer.c'],['../group__i8254.html#ga51322ddb267b4729d6b5f2bb05d49fff',1,'counter():&#160;timer.c']]],
  ['cur_5faspeed',['cur_aspeed',['../struct_anim_sprite.html#a3206cf4225f5833fca57857b8a52dd2f',1,'AnimSprite']]],
  ['cur_5ffig',['cur_fig',['../struct_anim_sprite.html#a1d1b9580302ed9fc1c0dde40feb6038e',1,'AnimSprite']]]
];

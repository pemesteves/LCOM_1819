var searchData=
[
  ['x',['x',['../struct_sprite.html#ab36028dcefdd4bf024c52c8d9519a283',1,'Sprite']]],
  ['x_5fov',['X_OV',['../group__i8042.html#gae2c4c6b26ddcdd376d41a1c3d0d1dcad',1,'8042.h']]],
  ['x_5fsign',['X_SIGN',['../group__i8042.html#ga181f1c2860e4d7fd7788990378061137',1,'8042.h']]],
  ['xpm',['XPM',['../group___x_p_m.html',1,'']]],
  ['xpm_2eh',['xpm.h',['../xpm_8h.html',1,'']]],
  ['xspeed',['xspeed',['../struct_sprite.html#a0907b8391344e8a3e4694985d5b7d5ad',1,'Sprite']]]
];

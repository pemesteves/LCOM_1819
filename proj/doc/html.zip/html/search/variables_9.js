var searchData=
[
  ['second_5fbuffer',['second_buffer',['../video_card_8c.html#a46f3bcf777b1c4f2c1882c08bbaef245',1,'videoCard.c']]],
  ['sp',['sp',['../struct_anim_sprite.html#a6573ed91ee9f3f9102cc54435af2fd94',1,'AnimSprite']]],
  ['state',['state',['../menu_8c.html#a02aa92a1a9796337161e74ab52351d32',1,'menu.c']]]
];

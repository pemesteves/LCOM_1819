var searchData=
[
  ['num_5ffig',['num_fig',['../struct_anim_sprite.html#a245ddba935a16902ed5227a596087277',1,'AnimSprite']]],
  ['numbytes',['numBytes',['../video_card_8c.html#aba4afc27b19632b6d6ec012bef286690',1,'videoCard.c']]]
];

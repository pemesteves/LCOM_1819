var searchData=
[
  ['is_5fbcd',['is_BCD',['../group___r_t_c.html#ga7f80b0929e0b77b08a1ad7a96f2bd503',1,'is_BCD():&#160;rtc.c'],['../group___r_t_c.html#ga7f80b0929e0b77b08a1ad7a96f2bd503',1,'is_BCD():&#160;rtc.c']]],
  ['issuemousecommand',['issueMouseCommand',['../group___mouse.html#ga2154bfa541436e1832665bf04be26298',1,'issueMouseCommand(uint8_t cmd):&#160;mouse.c'],['../group___mouse.html#ga2154bfa541436e1832665bf04be26298',1,'issueMouseCommand(uint8_t cmd):&#160;mouse.c']]]
];

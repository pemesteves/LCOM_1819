var searchData=
[
  ['y',['y',['../struct_sprite.html#a363e26017ee2aaed8636f7dab92af2cd',1,'Sprite']]],
  ['yspeed',['yspeed',['../struct_sprite.html#a7c1cf2ffe22e02c79be3ce23503c6bef',1,'Sprite']]]
];

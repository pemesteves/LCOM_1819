var searchData=
[
  ['x',['x',['../struct_sprite.html#ab36028dcefdd4bf024c52c8d9519a283',1,'Sprite']]],
  ['xspeed',['xspeed',['../struct_sprite.html#a0907b8391344e8a3e4694985d5b7d5ad',1,'Sprite']]]
];

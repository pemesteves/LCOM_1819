var searchData=
[
  ['alloc_5fhigh_5fscores',['alloc_high_scores',['../group___highscores.html#ga4edb3b8ac94ef8c5976ebe49efa2b874',1,'alloc_high_scores():&#160;high_scores.c'],['../group___highscores.html#ga4edb3b8ac94ef8c5976ebe49efa2b874',1,'alloc_high_scores():&#160;high_scores.c']]],
  ['animate_5fanimsprite',['animate_animSprite',['../group___anim_sprite.html#ga26b544ef65d4a06e53dfb73db0190bb7',1,'animate_animSprite(AnimSprite *sp):&#160;animSprite.c'],['../group___anim_sprite.html#ga26b544ef65d4a06e53dfb73db0190bb7',1,'animate_animSprite(AnimSprite *sp):&#160;animSprite.c']]]
];

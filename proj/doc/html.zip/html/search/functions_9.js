var searchData=
[
  ['reinitialize_5fjumpposition',['reinitialize_jumpPosition',['../group___sprite.html#gaa774ceba9a398d5d30cb7c7d90e2541a',1,'reinitialize_jumpPosition():&#160;sprite.c'],['../group___sprite.html#gaa774ceba9a398d5d30cb7c7d90e2541a',1,'reinitialize_jumpPosition():&#160;sprite.c']]]
];

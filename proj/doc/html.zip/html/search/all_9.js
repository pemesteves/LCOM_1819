var searchData=
[
  ['i8042',['i8042',['../group__i8042.html',1,'']]],
  ['i8254',['i8254',['../group__i8254.html',1,'']]],
  ['i8254_2eh',['i8254.h',['../i8254_8h.html',1,'']]],
  ['ibf',['IBF',['../group__i8042.html#ga3c48b10907056351582baf9f6478598e',1,'8042.h']]],
  ['ignore_5fcolor',['IGNORE_COLOR',['../group___proj.html#ga15f452617fb05eb96451053efaa4197a',1,'proj.h']]],
  ['in_5fbox',['IN_BOX',['../group___menu.html#ggae816e2010df6ae9e9f853d0f2c623173a8b0f1c94782d880e034c77434981e831',1,'menu.h']]],
  ['indexed_5fmode',['INDEXED_MODE',['../group___video_card.html#ga48fa70a72e330f89e31fcd6a44df06c9',1,'videoCard.h']]],
  ['initial',['INITIAL',['../group___menu.html#ggae816e2010df6ae9e9f853d0f2c623173a7116db6906963fd0720c4a85be250cf4',1,'menu.h']]],
  ['is_5fbcd',['is_BCD',['../group___r_t_c.html#ga7f80b0929e0b77b08a1ad7a96f2bd503',1,'is_BCD():&#160;rtc.c'],['../group___r_t_c.html#ga7f80b0929e0b77b08a1ad7a96f2bd503',1,'is_BCD():&#160;rtc.c']]],
  ['issuemousecommand',['issueMouseCommand',['../group___mouse.html#ga2154bfa541436e1832665bf04be26298',1,'issueMouseCommand(uint8_t cmd):&#160;mouse.c'],['../group___mouse.html#ga2154bfa541436e1832665bf04be26298',1,'issueMouseCommand(uint8_t cmd):&#160;mouse.c']]]
];

var searchData=
[
  ['v_5fres',['v_res',['../video_card_8c.html#a5bda1b499253a8fbf3cab646f8760391',1,'videoCard.c']]],
  ['video_5fmem',['video_mem',['../video_card_8c.html#a93a24e067b9083bed6fb5c0336fd7a01',1,'videoCard.c']]]
];

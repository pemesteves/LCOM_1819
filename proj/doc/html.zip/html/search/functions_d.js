var searchData=
[
  ['vbegetmodeinfo',['vbeGetModeInfo',['../group___video_card.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;videoCard.c'],['../group___video_card.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;videoCard.c']]],
  ['vg_5fdraw_5fhline',['vg_draw_hline',['../video_card_8c.html#a5e5b25bd525250f61f40b9e9f212d5e6',1,'videoCard.c']]],
  ['vg_5fdraw_5frectangle',['vg_draw_rectangle',['../video_card_8c.html#a99d2da2559e11200c6b40c469e9977ec',1,'videoCard.c']]],
  ['vg_5finit',['vg_init',['../video_card_8c.html#aa6c1ff5024cd4d15e476bce487584daa',1,'videoCard.c']]]
];

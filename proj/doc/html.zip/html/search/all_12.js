var searchData=
[
  ['save_5fhigh_5fscores',['save_high_scores',['../group___highscores.html#gac234b94287d9946b38a81a15561f8bd2',1,'save_high_scores(uint8_t numElem, uint32_t high_scores[], uint8_t name_size, char player_name[]):&#160;high_scores.c'],['../group___highscores.html#gac234b94287d9946b38a81a15561f8bd2',1,'save_high_scores(uint8_t numElem, uint32_t high_scores[], uint8_t name_size, char player_name[]):&#160;high_scores.c']]],
  ['second_5fbuffer',['second_buffer',['../video_card_8c.html#a46f3bcf777b1c4f2c1882c08bbaef245',1,'videoCard.c']]],
  ['seconds',['SECONDS',['../group___r_t_c.html#ga48fcf4f2eeef6769d588168d4ac2ab0e',1,'rtc.h']]],
  ['sky',['SKY',['../group___proj.html#gad46742e50b489787b1dd874fdd57a598',1,'proj.h']]],
  ['sp',['sp',['../struct_anim_sprite.html#a6573ed91ee9f3f9102cc54435af2fd94',1,'AnimSprite']]],
  ['speaker_5fctrl',['SPEAKER_CTRL',['../group__i8254.html#ga51b3a5e3d4811ca063fe25e35560ab40',1,'i8254.h']]],
  ['sprite',['Sprite',['../struct_sprite.html',1,'Sprite'],['../group___sprite.html',1,'(Global Namespace)']]],
  ['sprite_2ec',['sprite.c',['../sprite_8c.html',1,'']]],
  ['sprite_2eh',['sprite.h',['../sprite_8h.html',1,'']]],
  ['state',['state',['../menu_8c.html#a02aa92a1a9796337161e74ab52351d32',1,'menu.c']]],
  ['stream_5fmode',['STREAM_MODE',['../group__i8042.html#gab3919f33b46e0808c4ed1c56a6a423f2',1,'8042.h']]],
  ['swap_5fanimsprites',['swap_animSprites',['../group___anim_sprite.html#ga26845046bc3c000ce8432d5e608df398',1,'swap_animSprites(AnimSprite *sp1, AnimSprite *sp2):&#160;animSprite.c'],['../group___anim_sprite.html#ga26845046bc3c000ce8432d5e608df398',1,'swap_animSprites(AnimSprite *sp1, AnimSprite *sp2):&#160;animSprite.c']]],
  ['swap_5fsprites',['swap_sprites',['../group___sprite.html#gab81f8f7fd73f418ab396ac32d9d67f25',1,'swap_sprites(Sprite *sp1, Sprite *sp2):&#160;sprite.c'],['../group___sprite.html#gab81f8f7fd73f418ab396ac32d9d67f25',1,'swap_sprites(Sprite *sp1, Sprite *sp2):&#160;sprite.c']]],
  ['swap_5fstrings',['swap_strings',['../high__scores_8c.html#ac3f9bd483f000b5005de82279c390cd1',1,'high_scores.c']]]
];

var searchData=
[
  ['vbegetmodeinfo',['vbeGetModeInfo',['../group___video_card.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;videoCard.c'],['../group___video_card.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;videoCard.c']]]
];

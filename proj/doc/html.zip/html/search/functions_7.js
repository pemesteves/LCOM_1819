var searchData=
[
  ['main',['main',['../proj_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'proj.c']]],
  ['makejump',['makeJump',['../group___sprite.html#gaf190ff358474d32692353c51667f50b1',1,'makeJump(Sprite *sp):&#160;sprite.c'],['../group___sprite.html#gaf190ff358474d32692353c51667f50b1',1,'makeJump(Sprite *sp):&#160;sprite.c']]],
  ['menu',['menu',['../group___menu.html#gae83fcdbeb2b6757fc741ae953b633ee1',1,'menu():&#160;menu.c'],['../group___menu.html#gae83fcdbeb2b6757fc741ae953b633ee1',1,'menu():&#160;menu.c']]],
  ['menu_5fbackground_5falloc',['menu_background_alloc',['../group___menu.html#ga91d15674fe9484671f83f2add4ab94fb',1,'menu_background_alloc():&#160;menu.c'],['../group___menu.html#ga91d15674fe9484671f83f2add4ab94fb',1,'menu_background_alloc():&#160;menu.c']]],
  ['mouse_5fasm_5fih',['mouse_asm_ih',['../group___assembly.html#ga513ea301c5884e8b1a916080d7283071',1,'assembly.h']]],
  ['mouse_5fsubscribe_5fint',['mouse_subscribe_int',['../group___mouse.html#ga9da18257ff113b686bb826d154bfaa87',1,'mouse_subscribe_int(uint8_t *bit_no):&#160;mouse.c'],['../group___mouse.html#ga9da18257ff113b686bb826d154bfaa87',1,'mouse_subscribe_int(uint8_t *bit_no):&#160;mouse.c']]],
  ['mouse_5funsubscribe_5fint',['mouse_unsubscribe_int',['../group___mouse.html#ga685ad2706aca36d9869a30a19b9f446a',1,'mouse_unsubscribe_int():&#160;mouse.c'],['../group___mouse.html#ga685ad2706aca36d9869a30a19b9f446a',1,'mouse_unsubscribe_int():&#160;mouse.c']]],
  ['mouseirqset',['mouseIrqSet',['../group___mouse.html#ga639ec27488465ddfbcae31de798fb68a',1,'mouseIrqSet(bool enable):&#160;mouse.c'],['../group___mouse.html#ga639ec27488465ddfbcae31de798fb68a',1,'mouseIrqSet(bool enable):&#160;mouse.c']]]
];

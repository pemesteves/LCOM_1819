var indexSectionsWithContent =
{
  0: "8abcdefghijklmnoprstuvwxy",
  1: "as",
  2: "8aghikmprstvx",
  3: "acdfgikmprstuv",
  4: "abcghjmnrsvwxy",
  5: "c",
  6: "fi",
  7: "aghikmprsvx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules"
};


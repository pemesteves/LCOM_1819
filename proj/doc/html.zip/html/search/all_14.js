var searchData=
[
  ['uip',['UIP',['../group___r_t_c.html#ga3289eebd69837790d4aacaccd18d46db',1,'rtc.h']]],
  ['up_5farrow',['UP_ARROW',['../group__i8042.html#gad315ce436b88e78c266532e4714dd197',1,'8042.h']]],
  ['update_5fenemies_5fpositions',['update_enemies_positions',['../group___sprite.html#ga1f95e20e5ace4bdef3f816c7b0dba2ec',1,'update_enemies_positions(uint8_t num_enemies, Sprite *enemies[]):&#160;sprite.c'],['../group___sprite.html#ga1f95e20e5ace4bdef3f816c7b0dba2ec',1,'update_enemies_positions(uint8_t num_enemies, Sprite *enemies[]):&#160;sprite.c']]],
  ['updating_5fregisters',['updating_registers',['../group___r_t_c.html#ga2d2ac52832135c12f06bcbe96ea0b995',1,'updating_registers():&#160;rtc.c'],['../group___r_t_c.html#ga2d2ac52832135c12f06bcbe96ea0b995',1,'updating_registers():&#160;rtc.c']]],
  ['util_5fget_5flsb',['util_get_LSB',['../game_8c.html#a81621440b3d65680979425e39aa8c789',1,'game.c']]],
  ['util_5fget_5fmsb',['util_get_MSB',['../game_8c.html#a6a880076cd2ec468834438b6e0c58836',1,'game.c']]]
];

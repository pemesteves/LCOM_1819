var searchData=
[
  ['redscreenmask',['redScreenMask',['../video_card_8c.html#af842676947a895759ca38f7d4a684a7b',1,'videoCard.c']]]
];

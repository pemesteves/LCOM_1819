var searchData=
[
  ['in_5fbox',['IN_BOX',['../group___menu.html#ggae816e2010df6ae9e9f853d0f2c623173a8b0f1c94782d880e034c77434981e831',1,'menu.h']]],
  ['initial',['INITIAL',['../group___menu.html#ggae816e2010df6ae9e9f853d0f2c623173a7116db6906963fd0720c4a85be250cf4',1,'menu.h']]]
];

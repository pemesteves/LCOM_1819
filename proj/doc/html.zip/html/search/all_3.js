var searchData=
[
  ['check_5fcollision',['check_collision',['../sprite_8c.html#a28731741269df874c4ca4598c768e6f8',1,'sprite.c']]],
  ['check_5fcollisions',['check_collisions',['../group___sprite.html#ga75d4ea053ac45e4b7b5347d7fe200bb2',1,'check_collisions(Sprite *sp, uint8_t num_enemies, Sprite *enemies[], bool jumping):&#160;sprite.c'],['../group___sprite.html#ga75d4ea053ac45e4b7b5347d7fe200bb2',1,'check_collisions(Sprite *sp, uint8_t num_enemies, Sprite *enemies[], bool jumping):&#160;sprite.c']]],
  ['check_5fcursor_5fcollisions',['check_cursor_collisions',['../group___sprite.html#ga305d762a7ddaf0c92253ed58bd289763',1,'check_cursor_collisions(Sprite *cursor, Sprite *rectangle):&#160;sprite.c'],['../group___sprite.html#ga305d762a7ddaf0c92253ed58bd289763',1,'check_cursor_collisions(Sprite *cursor, Sprite *rectangle):&#160;sprite.c']]],
  ['check_5fkbc',['CHECK_KBC',['../group__i8042.html#ga55fefff08c94153a53592686472a6c80',1,'8042.h']]],
  ['check_5fkbd_5fint',['CHECK_KBD_INT',['../group__i8042.html#ga490d0115d3382cec5082fc21eb3a4092',1,'8042.h']]],
  ['clear_5fgame_5fscreen',['clear_game_screen',['../group___sprite.html#ga35dd37bc7364712b0987907510c0f5c4',1,'clear_game_screen(bool isDay, bool first_time_drawing_background):&#160;sprite.c'],['../group___sprite.html#ga35dd37bc7364712b0987907510c0f5c4',1,'clear_game_screen(bool isDay, bool first_time_drawing_background):&#160;sprite.c']]],
  ['code',['code',['../group___keyboard.html#ga966576744a473fafb7687f8e5649941f',1,'code():&#160;keyboard.c'],['../group___keyboard.html#ga966576744a473fafb7687f8e5649941f',1,'code():&#160;keyboard.c']]],
  ['convert_5fto_5fbinary',['convert_to_binary',['../group___r_t_c.html#gaf82940803f0fb006291b725adaf615c0',1,'convert_to_binary(uint8_t bcd_value):&#160;rtc.c'],['../group___r_t_c.html#gaf82940803f0fb006291b725adaf615c0',1,'convert_to_binary(uint8_t bcd_value):&#160;rtc.c']]],
  ['copytovram',['copyToVRAM',['../group___video_card.html#ga9d3a981cfc5e4f086a993f18fbdc56aa',1,'copyToVRAM():&#160;videoCard.c'],['../group___video_card.html#ga9d3a981cfc5e4f086a993f18fbdc56aa',1,'copyToVRAM():&#160;videoCard.c']]],
  ['counter',['counter',['../group__i8254.html#ga51322ddb267b4729d6b5f2bb05d49fff',1,'counter():&#160;timer.c'],['../group__i8254.html#ga51322ddb267b4729d6b5f2bb05d49fff',1,'counter():&#160;timer.c']]],
  ['create_5fanimsprite',['create_animSprite',['../group___anim_sprite.html#ga2634322f2c76f6e8e3a4df12e0033472',1,'create_animSprite(uint16_t xi, uint16_t yi, uint8_t no_pic, xpm_string_t pic1[],...):&#160;animSprite.c'],['../group___anim_sprite.html#ga2634322f2c76f6e8e3a4df12e0033472',1,'create_animSprite(uint16_t xi, uint16_t yi, uint8_t no_pic, xpm_string_t pic1[],...):&#160;animSprite.c']]],
  ['create_5fsprite',['create_sprite',['../group___sprite.html#gabe24ba25a12139fceee16a4eda42ede0',1,'create_sprite(const xpm_string_t pic[], int x, int y, int xspeed, int yspeed):&#160;sprite.c'],['../group___sprite.html#gabe24ba25a12139fceee16a4eda42ede0',1,'create_sprite(const xpm_string_t pic[], int x, int y, int xspeed, int yspeed):&#160;sprite.c']]],
  ['cur_5faspeed',['cur_aspeed',['../struct_anim_sprite.html#a3206cf4225f5833fca57857b8a52dd2f',1,'AnimSprite']]],
  ['cur_5ffig',['cur_fig',['../struct_anim_sprite.html#a1d1b9580302ed9fc1c0dde40feb6038e',1,'AnimSprite']]],
  ['cursor_5fstate',['cursor_state',['../group___menu.html#gae816e2010df6ae9e9f853d0f2c623173',1,'menu.h']]]
];

var searchData=
[
  ['obf',['OBF',['../group__i8042.html#ga45967c9e25447ba853cf6fb4ac545fe6',1,'8042.h']]],
  ['out_5fbuf',['OUT_BUF',['../group__i8042.html#gacfb42dde389e8ca36ab267002fbf5c6a',1,'8042.h']]]
];

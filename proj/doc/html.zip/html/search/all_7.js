var searchData=
[
  ['game',['game',['../group___game.html#gabb31b4c0e9b4f1d0c1d78749cbf21e75',1,'game(uint16_t xi, uint16_t yi, uint8_t fr_rate):&#160;game.c'],['../group___game.html#gabb31b4c0e9b4f1d0c1d78749cbf21e75',1,'game(uint16_t xi, uint16_t yi, uint8_t fr_rate):&#160;game.c'],['../group___game.html',1,'(Global Namespace)']]],
  ['game_2ec',['game.c',['../game_8c.html',1,'']]],
  ['game_2eh',['game.h',['../game_8h.html',1,'']]],
  ['game_5fbackground_5falloc',['game_background_alloc',['../group___game.html#gad1a90b0664ef2612094cdcf8d3384486',1,'game_background_alloc():&#160;game.c'],['../group___game.html#gad1a90b0664ef2612094cdcf8d3384486',1,'game_background_alloc():&#160;game.c']]],
  ['get_5fbits_5fper_5fpixel',['get_bits_per_pixel',['../group___video_card.html#ga719496aadf8f431ed96adace6df5576e',1,'get_bits_per_pixel():&#160;videoCard.c'],['../group___video_card.html#ga719496aadf8f431ed96adace6df5576e',1,'get_bits_per_pixel():&#160;videoCard.c']]],
  ['get_5fcharacter',['get_character',['../group___menu.html#ga9ed962fbd1adbe9113cff86fd0b8f14a',1,'get_character(char character):&#160;menu.c'],['../group___menu.html#ga9ed962fbd1adbe9113cff86fd0b8f14a',1,'get_character(char character):&#160;menu.c']]],
  ['get_5fcursor_5fevent',['get_cursor_event',['../menu_8c.html#af208f044e33e301ec5ea7a567c134622',1,'menu.c']]],
  ['get_5fdead_5fsprite',['get_dead_sprite',['../group___sprite.html#gaa15e0aa4ac1bd6df8deb722cab038691',1,'get_dead_sprite(int position, Sprite *sp, bool noTongue):&#160;sprite.c'],['../group___sprite.html#gaa15e0aa4ac1bd6df8deb722cab038691',1,'get_dead_sprite(int position, Sprite *sp, bool noTongue):&#160;sprite.c']]],
  ['get_5fh_5fres',['get_h_res',['../group___video_card.html#gac19350f0662b5c8fbb1a41e051411014',1,'get_h_res():&#160;videoCard.c'],['../group___video_card.html#gac19350f0662b5c8fbb1a41e051411014',1,'get_h_res():&#160;videoCard.c']]],
  ['get_5flast_5fhour_5fday',['get_last_hour_day',['../group___r_t_c.html#ga704a340790222884c4381f43103b5eed',1,'get_last_hour_day(uint8_t month):&#160;rtc.c'],['../group___r_t_c.html#ga704a340790222884c4381f43103b5eed',1,'get_last_hour_day(uint8_t month):&#160;rtc.c']]],
  ['get_5fmenu_5fbackground',['get_menu_background',['../group___menu.html#ga72fc065aab029c09279c64445bbeae2d',1,'get_menu_background():&#160;menu.c'],['../group___menu.html#ga72fc065aab029c09279c64445bbeae2d',1,'get_menu_background():&#160;menu.c']]],
  ['get_5fnumbytes',['get_numBytes',['../group___video_card.html#ga31571c83383919a9422e6343a2bbc292',1,'get_numBytes():&#160;videoCard.c'],['../group___video_card.html#ga31571c83383919a9422e6343a2bbc292',1,'get_numBytes():&#160;videoCard.c']]],
  ['get_5fregister_5fvalue',['get_register_value',['../group___r_t_c.html#gad60155d26e335c4f8e35688847caa919',1,'get_register_value(uint8_t port):&#160;rtc.c'],['../group___r_t_c.html#gad60155d26e335c4f8e35688847caa919',1,'get_register_value(uint8_t port):&#160;rtc.c']]],
  ['get_5fsecond_5fbuffer',['get_second_buffer',['../group___video_card.html#gab36ee9f61ffa1baaeb0e8df65fef9cc7',1,'get_second_buffer():&#160;videoCard.c'],['../group___video_card.html#gab36ee9f61ffa1baaeb0e8df65fef9cc7',1,'get_second_buffer():&#160;videoCard.c']]],
  ['get_5fsprite_5fnumber',['get_sprite_number',['../group___anim_sprite.html#ga5f912989626f02d211047025933073e0',1,'get_sprite_number(AnimSprite *sp):&#160;animSprite.c'],['../group___anim_sprite.html#ga5f912989626f02d211047025933073e0',1,'get_sprite_number(AnimSprite *sp):&#160;animSprite.c']]],
  ['get_5fv_5fres',['get_v_res',['../group___video_card.html#gab226d056720011120b05e68e5f4d4449',1,'get_v_res():&#160;videoCard.c'],['../group___video_card.html#gab226d056720011120b05e68e5f4d4449',1,'get_v_res():&#160;videoCard.c']]],
  ['get_5fvideo_5fmem',['get_video_mem',['../group___video_card.html#ga541e181cdbfecf6110d4d4c3ee087c30',1,'get_video_mem():&#160;videoCard.c'],['../group___video_card.html#ga541e181cdbfecf6110d4d4c3ee087c30',1,'get_video_mem():&#160;videoCard.c']]],
  ['grass',['GRASS',['../group___proj.html#ga0f6b2c5e6a922165582784ca418d0d17',1,'proj.h']]],
  ['greenscreenmask',['greenScreenMask',['../video_card_8c.html#a33a147be7923782fb8219e1641711fce',1,'videoCard.c']]],
  ['ground',['GROUND',['../group___proj.html#gaa5109b7484893febdf204af9312ffef1',1,'proj.h']]]
];

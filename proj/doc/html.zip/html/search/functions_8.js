var searchData=
[
  ['parsepacket',['parsePacket',['../group___mouse.html#ga850f40a4a0e02cd5c959001f4ef72553',1,'parsePacket(struct packet *pp, uint8_t bytes[]):&#160;mouse.c'],['../group___mouse.html#ga850f40a4a0e02cd5c959001f4ef72553',1,'parsePacket(struct packet *pp, uint8_t bytes[]):&#160;mouse.c']]],
  ['proj_5fmain_5floop',['proj_main_loop',['../proj_8c.html#a90aad768b0a0b41e4bcacc566b0cae6e',1,'proj.c']]],
  ['put_5fenemie_5fon_5fposition',['put_enemie_on_position',['../group___sprite.html#gadf5c333be073c851bec86a5880418f56',1,'put_enemie_on_position(uint8_t num_enemies, Sprite *enemies[], Sprite *new_enemy):&#160;sprite.c'],['../group___sprite.html#gadf5c333be073c851bec86a5880418f56',1,'put_enemie_on_position(uint8_t num_enemies, Sprite *enemies[], Sprite *new_enemy):&#160;sprite.c']]],
  ['put_5fhighscore',['put_highscore',['../group___highscores.html#ga74e28be99a1a815709d0a7635541531a',1,'put_highscore(uint32_t score, uint8_t numElem, uint32_t high_scores[]):&#160;high_scores.c'],['../group___highscores.html#ga74e28be99a1a815709d0a7635541531a',1,'put_highscore(uint32_t score, uint8_t numElem, uint32_t high_scores[]):&#160;high_scores.c']]]
];

var searchData=
[
  ['v_5fres',['v_res',['../video_card_8c.html#a5bda1b499253a8fbf3cab646f8760391',1,'videoCard.c']]],
  ['vbe_5fcall',['VBE_CALL',['../group___video_card.html#gaaa7fbe1e02a424af8eb9efc320d936c0',1,'videoCard.h']]],
  ['vbe_5fmode_5finfo',['VBE_MODE_INFO',['../group___video_card.html#ga2ecbf8f92f9322fedec91461747c4843',1,'videoCard.h']]],
  ['vbe_5fset_5fmode',['VBE_SET_MODE',['../group___video_card.html#ga02477c4996ff058aee590b54f2146eb5',1,'videoCard.h']]],
  ['vbegetmodeinfo',['vbeGetModeInfo',['../group___video_card.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;videoCard.c'],['../group___video_card.html#gab7c2361d75821337dec8a9a35c51ce2b',1,'vbeGetModeInfo(uint16_t mode, vbe_mode_info_t *vmi_p):&#160;videoCard.c']]],
  ['vc_5fint',['VC_INT',['../group___video_card.html#ga403202df7f734a04fdfb0961cfb4d6a9',1,'videoCard.h']]],
  ['vg_5fdraw_5fhline',['vg_draw_hline',['../video_card_8c.html#a5e5b25bd525250f61f40b9e9f212d5e6',1,'videoCard.c']]],
  ['vg_5fdraw_5frectangle',['vg_draw_rectangle',['../video_card_8c.html#a99d2da2559e11200c6b40c469e9977ec',1,'videoCard.c']]],
  ['vg_5finit',['vg_init',['../video_card_8c.html#aa6c1ff5024cd4d15e476bce487584daa',1,'videoCard.c']]],
  ['video_5fmem',['video_mem',['../video_card_8c.html#a93a24e067b9083bed6fb5c0336fd7a01',1,'videoCard.c']]],
  ['videocard',['VideoCard',['../group___video_card.html',1,'']]],
  ['videocard_2ec',['videoCard.c',['../video_card_8c.html',1,'']]],
  ['videocard_2eh',['videoCard.h',['../video_card_8h.html',1,'']]]
];
